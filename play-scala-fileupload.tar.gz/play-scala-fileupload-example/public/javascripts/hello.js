if (window.console) {
  console.log("Welcome to your Play application's JavaScript!");
}
